import sys
import math
from coppeliasim_zmqremoteapi_client import RemoteAPIClient


class RobotController:
    def __init__(self):
        self.client = RemoteAPIClient()
        self.sim = self.client.getObject('sim')
        pickupPart = self.sim.getObject('/pickupCylinder')
        auxMotor1 = self.sim.getObject("/auxMotor1")
        auxMotor2 = self.sim.getObject("/auxMotor2")
        gripperHandle = self.sim.getObject("/uarmGripper")
        modelBase = self.sim.getObject("/base")
        p = self.sim.getObjectPosition(pickupPart)
        #gripperHandle = self.sim.getObject("/uarmGripper")

    def connect(self):
        try:
            self.sim.startSimulation()
            return "Connected successfully"
        except Exception as e:
            return f"Connection failed: {str(e)}"

    def move_joint(self, joint_handle, target_position):
        try:
            self.sim.setJointTargetPosition(joint_handle, target_position)
            return f"Joint moved to position {target_position}"
        except Exception as e:
            return f"Failed to move joint: {str(e)}"

    def rotate_base_arm_10_degrees_clockwise(self):
        try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[0])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = -b * math.pi / 180  # Negative for clockwise rotation
            new_position = current_position + rotation
            
            # Set the new position for the base motor
            self.sim.setJointTargetPosition(motorHandles[0], new_position)
            return f"Base arm rotated {b} degrees clockwise"
        except Exception as e:
            return f"Failed to rotate base arm: {str(e)}"
    def rotate_base_arm_10_degrees_anticlockwise(self):
        try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[0])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = +b * math.pi / 180  # Negative for clockwise rotation
            new_position = current_position + rotation
            
            self.sim.setJointTargetPosition(motorHandles[0], new_position)
            return f"Base arm rotated {b} degrees clockwise"
        except Exception as e:
            return f"Failed to rotate base arm: {str(e)}"

    def rotate_mid_arm_10_degrees_anticlockwise(self):
        try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[1])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = +b * math.pi / 180  # Negative for clockwise rotation
            new_position = current_position + rotation
            
            self.sim.setJointTargetPosition(motorHandles[1], new_position)
            return f"mid arm rotated {b} degrees anticlockwise"
        except Exception as e:
            return f"Failed to rotate mid arm: {str(e)}"

    def rotate_mid_arm_10_degrees_clockwise(self):
        try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[1])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = -b * math.pi / 180  # Negative for clockwise rotation
            new_position = current_position + rotation
            
            self.sim.setJointTargetPosition(motorHandles[1], new_position)
            return f"Mid arm rotated {b} degrees clockwise"
        except Exception as e:
            return f"Failed to rotate base arm: {str(e)}"

    def rotate_end_arm_10_degrees_clockwise(self):
        try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[2])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = -b * math.pi / 180  # Negative for clockwise rotation
            new_position = current_position + rotation
            
            self.sim.setJointTargetPosition(motorHandles[2], new_position)
            return f"end arm rotated {b} degrees clockwise"
        except Exception as e:
            return f"Failed to rotate end arm: {str(e)}"

    def rotate_end_arm_10_degrees_anticlockwise(self):
        try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[2])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = b * math.pi / 180  # Negative for clockwise rotation
            new_position = current_position + rotation
            
            self.sim.setJointTargetPosition(motorHandles[2], new_position)
            return f"end arm rotated {b} degrees anticlockwise"
        except Exception as e:
            return f"Failed to rotate end arm: {str(e)}"

    def enableGripper(enable):
        global gripperHandle
        fakeOperation = False
        dat={}
        dat["fakeOperation"] = fakeOperation
        dat["enabled"]= enable
        sim.setBufferProperty(gripperHandle, "customData.activity", sim.packTable(dat))

    
'''    def grip(self):
        try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[3])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = 10 * math.pi / 180  # Negative for clockwise rotation
            new_position = 0
            
            self.sim.setJointTargetPosition(motorHandles[3], new_position)
            return "gripped by 10 degrees"
        except Exception as e:
            return f"Failed to grip: {str(e)}"'''

    #def ungrip(self):
    #    enable
'''         try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[3])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = -10 * math.pi / 180  # Negative for clockwise rotation
            new_position = math.pi/2
            
            self.sim.setJointTargetPosition(motorHandles[3], new_position)
            return "ungripped by 10 degrees"
        except Exception as e:
            return f"Failed to ungrip: {str(e)}"'''


if __name__ == "__main__":
    controller = RobotController()
    print(controller.connect())
    global b
    while True:
      a = input("Enter command:\n")
      try:
            b = int(a[-2:])
            a = a[:-2].lower()
      except ValueError:
            b = 10
            a = a.lower()
        
        #print(a, b)
      try:
        if a == 'bcw':
            print(controller.rotate_base_arm_10_degrees_clockwise())
        elif a == 'bccw':
            print(controller.rotate_base_arm_10_degrees_anticlockwise())

        elif a == 'mcw':
                print(controller.rotate_mid_arm_10_degrees_clockwise())
        elif a == 'mccw':
                print(controller.rotate_mid_arm_10_degrees_anticlockwise())
                
        elif a == 'eccw':
                print(controller.rotate_end_arm_10_degrees_anticlockwise())
        elif a == 'ecw':
                print(controller.rotate_end_arm_10_degrees_clockwise())
                
        elif a == "grip":
                print(controller.enableGripper(True))
        elif a == "ungrip":
                print(controller.enableGripper(False))
        else:
            print("Enter correct commands!")
      except Exception as e:
        print(e)
                

