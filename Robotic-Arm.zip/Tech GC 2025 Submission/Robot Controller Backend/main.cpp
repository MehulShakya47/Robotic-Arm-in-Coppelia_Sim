#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>

// Undefine slots to avoid conflict with Python headers
#ifdef slots
#undef slots
#endif

// Include Python headers
#define PY_SSIZE_T_CLEAN
#include <Python.h>

// Redefine slots for Qt
#define slots Q_SLOTS

class RobotBridge : public QObject
{
    Q_OBJECT

public:
    RobotBridge() {

            Py_Initialize();
        PyRun_SimpleString("import sys; sys.path.append('C:/Users/Hp/OneDrive - IIT Delhi/Desktop/QT_projects/Robotic Arm')");

        pModule = PyImport_ImportModule("robot_control");
        if (pModule == nullptr) {
            PyErr_Print();
            throw std::runtime_error("Failed to load the Python module.");
        }
        pClass = PyObject_GetAttrString(pModule, "RobotController");
        if (pClass == nullptr) {
            PyErr_Print();
            throw std::runtime_error("Failed to get the RobotController class.");
        }
        pInstance = PyObject_CallObject(pClass, NULL);
        if (pInstance == nullptr) {
            PyErr_Print();
            throw std::runtime_error("Failed to create an instance of RobotController.");
        }
    }

    ~RobotBridge() {
        Py_XDECREF(pInstance);
        Py_XDECREF(pClass);
        Py_XDECREF(pModule);
        Py_Finalize();
    }


    Q_INVOKABLE QString rotate_base_arm_5_degrees_clockwise() {
        PyObject* pValue = PyObject_CallMethod(pInstance, "rotate_base_arm_5_degrees_clockwise", NULL);
        if (pValue == nullptr) {
            PyErr_Print();
            return "Error calling rotate_base_arm_5_degrees method";
        }
        QString result = QString::fromUtf8(PyUnicode_AsUTF8(pValue));
        Py_DECREF(pValue);
        return result;
    }
    Q_INVOKABLE QString rotate_base_arm_5_degrees_anticlockwise() {
        PyObject* pValue = PyObject_CallMethod(pInstance, "rotate_base_arm_5_degrees_anticlockwise", NULL);
        if (pValue == nullptr) {
            PyErr_Print();
            return "Error calling rotate_base_arm_5_degrees method";
        }
        QString result = QString::fromUtf8(PyUnicode_AsUTF8(pValue));
        Py_DECREF(pValue);
        return result;
    }
    Q_INVOKABLE QString  move_gripper_radial() {
        PyObject* pValue = PyObject_CallMethod(pInstance, "move_gripper_radial", NULL);
        if (pValue == nullptr) {
            PyErr_Print();
            return "Error calling move_gripper_radial";
        }
        QString result = QString::fromUtf8(PyUnicode_AsUTF8(pValue));
        Py_DECREF(pValue);
        return result;
    }
    Q_INVOKABLE QString  move_gripper_radial_in() {
        PyObject* pValue = PyObject_CallMethod(pInstance, "move_gripper_radial_in", NULL);
        if (pValue == nullptr) {
            PyErr_Print();
            return "Error calling move_gripper_radial";
        }
        QString result = QString::fromUtf8(PyUnicode_AsUTF8(pValue));
        Py_DECREF(pValue);
        return result;
    }

    Q_INVOKABLE QString movegripper_up() {
        PyObject* pValue = PyObject_CallMethod(pInstance, "move_gripper_up", NULL);
        if (pValue == nullptr) {
            PyErr_Print();
            return "Error calling move_joint method";
        }
        QString result = QString::fromUtf8(PyUnicode_AsUTF8(pValue));
        Py_DECREF(pValue);
        return result;
    }
    Q_INVOKABLE QString movegripper_down() {
        PyObject* pValue = PyObject_CallMethod(pInstance, "move_gripper_down", NULL);
        if (pValue == nullptr) {
            PyErr_Print();
            return "Error calling move_joint method";
        }
        QString result = QString::fromUtf8(PyUnicode_AsUTF8(pValue));
        Py_DECREF(pValue);
        return result;
    }
    Q_INVOKABLE QString enable_gripper_true() {
        PyObject* pValue = PyObject_CallMethod(pInstance, "enable_gripper_true", NULL);
        if (pValue == nullptr) {
            PyErr_Print();
            return "Error calling move_joint method";
        }
        QString result = QString::fromUtf8(PyUnicode_AsUTF8(pValue));
        Py_DECREF(pValue);
        return result;
    }
    Q_INVOKABLE QString enable_gripper_false() {
        PyObject* pValue = PyObject_CallMethod(pInstance, "enable_gripper_false", NULL);
        if (pValue == nullptr) {
            PyErr_Print();
            return "Error calling move_joint method";
        }
        QString result = QString::fromUtf8(PyUnicode_AsUTF8(pValue));
        Py_DECREF(pValue);
        return result;
    }

private:
    PyObject *pModule, *pClass, *pInstance;
};

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    // Create an instance of RobotBridge
    RobotBridge robotBridge;

    // Expose the RobotBridge instance to QML
    engine.rootContext()->setContextProperty("robotBridge", &robotBridge);

    // Load the QML file
    engine.load(QUrl(QStringLiteral("qrc:/new/prefix1/MAIN.qml")));

    if (engine.rootObjects().isEmpty()) {
        return -1;
    }

    return app.exec();
}

#include "main.moc"



