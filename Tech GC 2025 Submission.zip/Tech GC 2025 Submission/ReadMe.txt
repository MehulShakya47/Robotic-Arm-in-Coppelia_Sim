1. Download the zip file.
2. Load the scene provided termed as "final scene" after properly downloading coppeliasim simulation software.
3. On your Bash/Windows Terminal run the following commands:
	python -m pip install coppeliasim-zmqremoteapi-client
	python -m pip install cbor cbor2
	python -m pip install numpy PyQt5 PyQt5-Qt5 PyQt_sip
	python -m pip install pyzmq
4. Try out the robot controller:Open the executable file "myApp" under the Robot_Controller directory within the zip file.
5. For terminal commands for usage of controller:
	run the Python Terminal Launcher in IDE of choice or just double-click the file.
 We tried to implement the voice control LLM model but couldn't due to time constraints, so all the work that could've been done regarding the model is attached in the directory Voice Control Backend