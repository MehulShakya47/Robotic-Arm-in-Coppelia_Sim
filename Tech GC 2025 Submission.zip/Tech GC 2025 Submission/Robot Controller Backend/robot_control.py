import sys
import math
from coppeliasim_zmqremoteapi_client import RemoteAPIClient

class RobotController:
    def __init__(self):
        self.client = RemoteAPIClient()
        self.sim = self.client.getObject('sim')
        self.robot_handle = self.sim.getObject('/uarmGripper')
        self.pickupPart = self.sim.getObject('/pickupCylinder')
        self.auxMotor1 = self.sim.getObject("/auxMotor1")
        self.auxMotor2 = self.sim.getObject("/auxMotor2")
        self.gripperHandle = self.sim.getObject("/uarmGripper")
        self.modelBase = self.sim.getObject("/base")
        p = self.sim.getObjectPosition(self.pickupPart)
        # self.script_handle = self.sim.getScript(self.sim.scripttype_customizationscript, self.robot_handle)
        # if self.script_handle == -1:
        #     print("Error: Could not find the script attached to the robot")
    def _compute_angles_from_position(self, absolute_position, vertical_offset=0, radial_offset=0):
        m = self.sim.getObjectMatrix(self.sim.getObject('/motor1'))
        m = self.sim.getMatrixInverse(m)
        p = self.sim.multiplyVector(m, absolute_position)
        joint_angles = [0, 0, 0, 0]
        joint_angles[0] = math.atan2(p[1], p[0]) + math.pi

        if joint_angles[0] > math.pi * 3/2:
            joint_angles[0] = joint_angles[0] - math.pi * 2

        v = p[2] - 0.0895 + 0.0592 + vertical_offset
        r = math.sqrt(p[0]**2 + p[1]**2) - 0.0204 - 0.0346 + radial_offset
        h = math.sqrt(r**2 + v**2)
        l1, l2 = 0.148, 0.16

        if abs(l1**2 + l2**2 - h**2) / (2 * l1 * l2) > 1:
            return None

        t2 = math.pi - math.acos((l1**2 + l2**2 - h**2) / (2 * l1 * l2))

        if abs((l1**2 + h**2 - l2**2) / (2 * l1 * h)) > 1:
            return None

        al = math.acos((l1**2 + h**2 - l2**2) / (2 * l1 * h))
        t1 = math.atan2(v, r) + al
        t2 = 0.6484 - (t1 - t2)
        t1 = t1 + 0.281
        joint_angles[1] = t1
        joint_angles[2] = t2

        return joint_angles

    def compute_angles_from_suction_cup_position(self, absolute_position, vertical_offset=0, radial_offset=0):
        return self._compute_angles_from_position(absolute_position, vertical_offset, radial_offset)

    def compute_angles_from_gripper_position(self, absolute_position, vertical_offset=0, radial_offset=0):
        return self._compute_angles_from_position(absolute_position, vertical_offset - 0.039, radial_offset - 0.048)

    def move_to_position(self, new_motor_positions, synchronous=True, max_vel=None, max_accel=None, max_jerk=None):
        max_vel_vect = [0] * 4
        max_accel_vect = [0] * 4
        max_jerk_vect = [0] * 4
        default_max = [math.pi/2, math.pi/2, math.pi, math.pi]

        for i in range(4):
            max_vel_vect[i] = max(1 * math.pi / 180, min(max_vel or default_max[i], default_max[i]))
            max_accel_vect[i] = max(1 * math.pi / 180, min(max_accel or default_max[i], default_max[i]))
            max_jerk_vect[i] = max(1 * math.pi / 180, min(max_jerk or default_max[i], default_max[i]))

        op = self.sim.ruckig_nosync if not synchronous else -1

        params = {
            "joints": [self.sim.getObject(f"/motor{i+1}") for i in range(4)],
            "targetPos": new_motor_positions,
            "maxVel": max_vel_vect,
            "maxAccel": max_accel_vect,
            "maxJerk": max_jerk_vect,
            "flags": op
        }
        self.sim.moveToConfig(params)

    def get_joint_positions(self):
        return [self.sim.getJointTargetPosition(self.sim.getObject(f"/motor{i+1}")) for i in range(4)]

    def initialize(self, max_vel, max_accel, max_jerk, max_torque):
        for i in range(4):
            motor = self.sim.getObject(f"/motor{i+1}")
            self.sim.setJointTargetForce(motor, max_torque)
            self.sim.setObjectFloatParam(motor, self.sim.jointfloatparam_maxvel, max_vel)

    def enable_gripper(self, enable):
        fake_operation = False
        data = {"fakeOperation": fake_operation, "enabled": enable}
        self.sim.setBufferProperty(self.gripperHandle, "customData.activity", self.sim.packTable(data))
    def enable_gripper_true(self):
        self.enable_gripper(False)
    def enable_gripper_false(self):
        self.enable_gripper(True)
    def move_forward(self, distance):
        base_motor = self.sim.getObject("/motor1")
        gripper = self.sim.getObject("/uarmGripper")
        base_motor_pos = self.sim.getObjectPosition(base_motor)
        gripper_pos = self.sim.getObjectPosition(gripper)
        difference = [gripper_pos[i] - base_motor_pos[i] for i in range(2)]
        mag_squared = sum(d**2 for d in difference)
        new_gripper_pos = list(gripper_pos)
        for i in range(2):
            difference[i] = difference[i] / (mag_squared**0.5)
            new_gripper_pos[i] = gripper_pos[i] + difference[i] * distance
        new_gripper_pos.append(gripper_pos[2])  # Keep Z-coordinate unchanged
        angles = self.compute_angles_from_gripper_position(new_gripper_pos)
        if angles:
            self.move_to_position(angles, True)
        else:
            print("Error: Unable to compute joint angles for the target position.")
    def move_gripper_up(self, up_or_down=1, distance=0.02):
    # Get current gripper position in WORLD coordinates
        gripper_handle = self.sim.getObject('/uarmGripper')
        current_position = self.sim.getObjectPosition(gripper_handle, -1)
        
        # Calculate new Z position
        new_position = [
            current_position[0],  # Keep X
            current_position[1],   # Keep Y
            current_position[2] + (distance * up_or_down)  # Adjust Z
        ]
        
        # Compute angles with original Lua script offsets
        joint_angles = self._compute_angles_from_position(
            absolute_position=new_position,
            vertical_offset=-0.0385,   # From Lua: verticalOffset-0.039
            radial_offset=0.00845      # From Lua: radialOffset-0.048
        )
        
        if joint_angles:
            self.move_to_position(
                joint_angles,
                synchronous=True,
                max_vel=45*math.pi/180,
                max_accel=40*math.pi/180,
                max_jerk=80*math.pi/180
            )
            return f"Moved gripper {'up' if up_or_down > 0 else 'down'} {distance}m"
        else:
            print("Invalid target position")
            return
    def move_gripper_down(self, up_or_down=-1, distance=0.02):
    # Get current gripper position in WORLD coordinates
        gripper_handle = self.sim.getObject('/uarmGripper')
        current_position = self.sim.getObjectPosition(gripper_handle, -1)
        
        # Calculate new Z position
        new_position = [
            current_position[0],  # Keep X
            current_position[1],   # Keep Y
            current_position[2] + (distance * up_or_down)  # Adjust Z
        ]
        
        # Compute angles with original Lua script offsets
        joint_angles = self._compute_angles_from_position(
            absolute_position=new_position,
            vertical_offset=-0.0385,   # From Lua: verticalOffset-0.039
            radial_offset=0.00845      # From Lua: radialOffset-0.048
        )
        
        if joint_angles:
            self.move_to_position(
                joint_angles,
                synchronous=True,
                max_vel=45*math.pi/180,
                max_accel=40*math.pi/180,
                max_jerk=80*math.pi/180
            )
            return f"Moved gripper {'up' if up_or_down > 0 else 'down'} {distance}m"
        else:
            print("Invalid target position")
            return

    
        
    def move_gripper_radial(self):
        # distance=0.02
        # gripper_handle = self.sim.getObject('/uarmGripper')
        # current_position = self.sim.getObjectPosition(gripper_handle, -1)
        
        # base_handle = self.sim.getObject('/motor1')
        # base_position = self.sim.getObjectPosition(base_handle, -1)
        
        # # Original direction calculation
        # direction = [
        #     current_position[0] - base_position[0],
        #     current_position[1] - base_position[1],
        #     0
        # ]
        
        # length = math.hypot(direction[0], direction[1])
        # if length < 1e-6:
        #     return False
            
        # direction = [d/length for d in direction]
        
        # new_position = [
        #     current_position[0] + direction[0] * distance,
        #     current_position[1] + direction[1] * distance,
        #     current_position[2]
        # ]
        
        # Original offset values
        step=5
        angles=self._compute_angles_from_position(self.sim.getObjectPosition(self.robot_handle),-0.0372,0.00845+0.001*step)
        self.move_to_position(angles, True)

        
        # if joint_angles:
        #     self.move_to_position(joint_angles)
        #     return True
        # return False
    def move_gripper_radial_in(self):
        
        # Original offset values
        step=-5
        angles=self._compute_angles_from_position(self.sim.getObjectPosition(self.robot_handle),-0.0372,0.00845+0.001*step)
        self.move_to_position(angles, True)


    def rotate_base_arm_5_degrees_clockwise(self):
        try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[0])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = +3 * math.pi / 180  # Negative for clockwise rotation
            new_position = current_position + rotation
            
            # Set the new position for the base motor
            self.sim.setJointTargetPosition(motorHandles[0], new_position)
            return "Base arm rotated 5 degrees clockwise"
        except Exception as e:
            return f"Failed to rotate base arm: {str(e)}"
    def rotate_base_arm_5_degrees_anticlockwise(self):
        try:
            motorHandles = [-1, -1, -1, -1]
            for i in range(1, 5):
                motorHandles[i-1] = self.sim.getObject("/motor"+str(i))

            # Get the current position of the base motor
            current_position = self.sim.getJointPosition(motorHandles[0])
            
            # Calculate the new position (5 degrees clockwise)
            rotation = -3 * math.pi / 180  # Negative for clockwise rotation
            new_position = current_position + rotation
            self.sim.setJointTargetPosition(motorHandles[0], new_position)
            return "Base arm rotated 5 degrees clockwise"
        except Exception as e:
            return f"Failed to rotate base arm: {str(e)}"
        

# For testing purposes
if __name__ == "__main__":
    controller = RobotController()
    print(controller.connect())
    print(controller.rotate_base_arm_5_degrees())








####################################################################
# sim=require'sim'

# function _computeAnglesFromPosition(absolutePosition,verticalOffset,radialOffset)
#     local voff=0
#     local rOff=0
#     if verticalOffset then
#         voff=verticalOffset
#     end
#     if radialOffset then
#         rOff=radialOffset
#     end
#     local m=sim.getObjectMatrix(motorHandles[1])
#     m=sim.getMatrixInverse(m)
#     local p=sim.multiplyVector(m,absolutePosition)
#     local jointAngles={0,0,0,0}
#     jointAngles[1]=math.atan2(p[2],p[1])+math.pi
#     if jointAngles[1]>math.pi*3/2 then
#         jointAngles[1]=jointAngles[1]-math.pi*2
#     end
#     local v=p[3]-0.0895+0.0592+voff
#     local r=math.sqrt(p[1]*p[1]+p[2]*p[2])-0.0204-0.0346+rOff
#     local h=math.sqrt(r*r+v*v)
#     local l1=0.148
#     local l2=0.16
#     if math.abs((l1*l1+l2*l2-(h*h))/(2*l1*l2))>1 then
#         return nil
#     end
#     local t2=math.pi-math.acos((l1*l1+l2*l2-(h*h))/(2*l1*l2))
#     if math.abs((l1*l1+h*h-l2*l2)/(2*l1*h))>1 then
#         return nil
#     end
#     local al=math.acos((l1*l1+h*h-l2*l2)/(2*l1*h))
#     local t1=math.atan2(v,r)+al
#     t2=0.6484-(t1-t2)
#     t1=t1+0.281
#     jointAngles[2]=t1
#     jointAngles[3]=t2
#     return jointAngles
# end

# function computeAnglesFromSuctionCupPosition(absolutePosition,verticalOffset,radialOffset)
#     return _computeAnglesFromPosition(absolutePosition,verticalOffset,radialOffset)
# end

# function computeAnglesFromGripperPosition(absolutePosition,verticalOffset,radialOffset)
#     return _computeAnglesFromPosition(absolutePosition,verticalOffset-0.039,radialOffset-0.048)
# end

# function initialize(maxVel,maxAccel,maxJerk,maxTorque)
#     motorHandles={-1,-1,-1,-1}
#     for i=1,4,1 do
#         motorHandles[i]=sim.getObject('../motor'..i)
#         sim.setJointTargetForce(motorHandles[i],maxTorque)
#         sim.setObjectFloatParam(motorHandles[i],sim.jointfloatparam_maxvel,maxVel)
#     end
#     auxMotor1=sim.getObject('../auxMotor1')
#     auxMotor2=sim.getObject('../auxMotor2')

#     maxVelVect={maxVel,maxVel,maxVel,maxVel}
#     maxAccelVect={maxAccel,maxAccel,maxAccel,maxAccel}
#     maxJerkVect={maxJerk,maxJerk,maxJerk,maxJerk}
# end

# function moveToPosition(newMotorPositions,synchronous,maxVel,maxAccel,maxJerk)
#     local _maxVelVect={}
#     local _maxAccelVect={}
#     local _maxJerkVect={}
#     if not maxVel then
#         maxVel=maxVelVect[1]
#     end
#     if not maxAccel then
#         maxAccel=maxAccelVect[1]
#     end
#     if not maxJerk then
#         maxJerk=maxJerkVect[1]
#     end
#     for i=1,4,1 do
#         _maxVelVect[i]=math.max(1*math.pi/180,math.min(maxVel,maxVelVect[i]))
#         _maxAccelVect[i]=math.max(1*math.pi/180,math.min(maxAccel,maxAccelVect[i]))
#         _maxJerkVect[i]=math.max(1*math.pi/180,math.min(maxJerk,maxJerkVect[i]))
#     end
#     local op=sim.ruckig_nosync
#     if synchronous then
#         op=-1
#     end
#     local params = {
#         joints = motorHandles,
#         targetPos = newMotorPositions,
#         maxVel = _maxVelVect,
#         maxAccel = _maxAccelVect,
#         maxJerk = _maxJerkVect,
#         flags = op,
#     }
#     sim.moveToConfig(params)
# end

# function enableGripper(enable)
#     local fakeOperation=false
#     local dat={}
#     dat.fakeOperation=fakeOperation
#     dat.enabled=enable
#     sim.setBufferProperty(gripperHandle, 'customData.activity',sim.packTable(dat))
# end

# function sysCall_thread()
#     modelBase=sim.getObject('..')
#     gripperHandle=sim.getObject('../uarmGripper')
#     pickupPart=sim.getObject('../pickupCylinder')
#     sim.setObjectParent(pickupPart,-1,true)
#     local maxVelocity=45*math.pi/180 -- rad/s
#     local maxAcceleration=40*math.pi/180 -- rad/s^2
#     local maxJerk=80*math.pi/180 -- rad/s^3
#     local maxTorque=10 -- kg*m^2/s^2

#     initialize(maxVelocity,maxAcceleration,maxJerk,maxTorque)

# end

# function sysCall_joint(inData)
#     if inData.handle==auxMotor1 then
#         local t2=-sim.getJointPosition(motorHandles[2])+104*math.pi/180
#         local t3=sim.getJointPosition(motorHandles[3])-59.25*math.pi/180
#         error=t3-t2-inData.pos
#     end
#     if inData.handle==auxMotor2 then
#         local t3=sim.getJointPosition(motorHandles[3])-59.25*math.pi/180
#         error=-t3-inData.pos
#     end
#     local ctrl=error*20
    
#     local maxVelocity=ctrl
#     if (maxVelocity>inData.maxVel) then
#         maxVelocity=inData.maxVel
#     end
#     if (maxVelocity<-inData.maxVel) then
#         maxVelocity=-inData.maxVel
#     end
#     local forceOrTorqueToApply=inData.maxForce

#     local outData={}
#     outData.vel=maxVelocity
#     outData.force=forceOrTorqueToApply
#     return outData
# end